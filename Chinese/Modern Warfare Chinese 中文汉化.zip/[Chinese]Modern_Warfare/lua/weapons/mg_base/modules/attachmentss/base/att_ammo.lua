ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Ammo"
ATTACHMENT.Category = "弹药"
function ATTACHMENT:OnImpact(weapon, dmgInfo, tr)
end