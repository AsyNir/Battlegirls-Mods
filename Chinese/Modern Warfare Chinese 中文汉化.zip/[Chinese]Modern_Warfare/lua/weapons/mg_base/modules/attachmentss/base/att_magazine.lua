ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Magazine"
ATTACHMENT.Category = "弹匣"
ATTACHMENT.BulletList = {}
ATTACHMENT._lastClip = -1

local small = Vector(1, 1, 1)
local normal = Vector(1, 1, 1)

function ATTACHMENT:RemoveBulletsBasedOnClip(weapon)
    if (weapon:Clip1() != self._lastClip) then
        for i, bone in pairs(self.BulletList) do
            local bId = self.m_Model:LookupBone(bone)

            if (bId != nil) then
                self.m_Model:ManipulateBoneScale(bId, weapon:Clip1() <= i && small || normal)
            end
        end

        self._lastClip = weapon:Clip1()
    end
end

function ATTACHMENT:Render(weapon)
    --self:RemoveBulletsBasedOnClip(weapon)
    --whole mag becomes invisible and i can't figure out why
end

function ATTACHMENT:ResetBullets(weapon)
    for i, bone in pairs(self.BulletList) do
        if (weapon:Clip1() + weapon:Ammo1() >= i) then
            local bId = self.m_Model:LookupBone(self.m_Model, bone)
            
            if (bId != nil) then
                self.m_Model:ManipulateBoneScale(bId, normal)
            end
        end
    end
end