ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Pistol Grip"
ATTACHMENT.Category = "手枪握把"