ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Sight"
ATTACHMENT.Category = "瞄具"