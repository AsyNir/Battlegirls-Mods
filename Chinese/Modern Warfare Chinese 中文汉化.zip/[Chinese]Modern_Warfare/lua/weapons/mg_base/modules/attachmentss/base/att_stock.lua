ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Barrel"
ATTACHMENT.Category = "枪托"