ATTACHMENT.Base = "att_perk"
ATTACHMENT.Name = "快速换弹"
ATTACHMENT.Icon = Material("viper/mw/attachments/icons/perks/perk_icon_fastreload.vmt")