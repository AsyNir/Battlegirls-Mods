AddCSLuaFile()

SWEP.StatDefinitions = {
    ["SWEP.Primary.ClipSize"] = "ClipSize",
    ["SWEP.Primary.RPM"] = "RPM",
    ["SWEP.Animations.Ads_Out.Fps"] = "AimSpeed",
    ["SWEP.Animations.Ads_In.Fps"] = "AimSpeed",
    ["SWEP.Animations.Sprint_Out.Fps"] = "SprintSpeed",
    ["SWEP.Animations.Rechamber.Fps"] = "RechamberSpeed",
    ["SWEP.Cone.Ads"] = "Accuracy",
    ["SWEP.Cone.Hip"] = "Accuracy",
    ["SWEP.Cone.Increase"] = "ConeIncrease",
    --["SWEP.Animations.Reload.Length"] = "ReloadLength",
   -- ["SWEP.Animations.Reload_Empty.Length"] = "ReloadLength", --too confusing for people
    ["SWEP.Animations.Reload.Fps"] = "ReloadSpeed",
    ["SWEP.Animations.Reload_Empty.Fps"] = "ReloadSpeed",
    ["SWEP.Animations.Reload_Start.Fps"] = "ReloadSpeed",
    ["SWEP.Animations.Draw.Fps"] = "SwitchSpeed",
    ["SWEP.Animations.Holster.Fps"] = "SwitchSpeed",
    ["SWEP.Bullet.Damage.1"] = "DamageClose",
    ["SWEP.Bullet.Damage.2"] = "DamageRange",
    ["SWEP.Bullet.HeadshotMultiplier"] = "HeadshotMultiplier",
    ["SWEP.Bullet.EffectiveRange"] = "EffectiveRange",
    ["SWEP.Bullet.Penetration.Thickness"] = "PenetrationThickness",
    ["SWEP.Recoil.Vertical.1"] = "VerticalRecoil",
    ["SWEP.Recoil.AdsMultiplier"] = "Recoil",
    ["SWEP.Recoil.Vertical.2"] = "VerticalRecoil",
    ["SWEP.Recoil.Horizontal.1"] = "HorizontalRecoil",
    ["SWEP.Recoil.Horizontal.2"] = "HorizontalRecoil",
    ["SWEP.Recoil.Shake"] = "Shake",
    ["SWEP.Animations.Melee_Hit.Length"] = "MeleeSpeed",
    ["SWEP.Animations.Melee.Length"] = "MeleeSpeed",
    ["SWEP.Animations.Melee_Hit.Damage"] = "MeleeDamage",
    ["SWEP.Projectile.Speed"] = "ProjectileSpeed",
    ["SWEP.Projectile.Gravity"] = "ProjectileGravity",
    ["SWEP.Bullet.NumBullets"] = "Bullets"
}

SWEP.StatInfo = {
    ["Shake"] = {
        Name = "瞄准稳定性",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["HeadshotMultiplier"] = {
        Name = "爆头伤害",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["ProjectileSpeed"] = {
        Name = "射击速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["ProjectileGravity"] = {
        Name = "射击稳定性",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["ClipSize"] = {
        Name = "弹匣容量",
        ProIfMore = true,
        ShowPercentage = false
    },
    ["RPM"] = {
        Name = "每分钟几发",
        ProIfMore = true,
        ShowPercentage = false
    },
    ["AimSpeed"] = {
        Name = "开镜速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["SprintSpeed"] = {
        Name = "冲刺到开枪速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["AimLength"] = {
        Name = "瞄准时间",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["RechamberSpeed"] = {
        Name = "换弹速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["AimAccuracy"] = {
        Name = "机瞄弹道扩散",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["ConeIncrease"] = {
        Name = "弹道偏移",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["Accuracy"] = {
        Name = "弹道扩散",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["ReloadSpeed"] = {
        Name = "装填速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["SwitchSpeed"] = {
        Name = "射击速度",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["DrawLength"] = {
        Name = "拔枪时间",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["HolsterLength"] = {
        Name = "收枪时间",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["ReloadLength"] = {
        Name = "装填时间",
        ProIfMore = false,
        ShowPercentage = false
    },
    ["DamageClose"] = {
        Name = "最近伤害",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["DamageRange"] = {
        Name = "最远伤害",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["EffectiveRange"] = {
        Name = "有效射程",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["MaxRange"] = {
        Name = "最远射程",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["PenetrationThickness"] = {
        Name = "穿透力",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["HorizontalRecoil"] = {
        Name = "水平后坐力",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["Recoil"] = {
        Name = "后坐力",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["VerticalRecoil"] = {
        Name = "垂直后坐力",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["MeleeSpeed"] = {
        Name = "近战恢复速度",
        ProIfMore = false,
        ShowPercentage = true
    },
    ["MeleeDamage"] = {
        Name = "近战伤害",
        ProIfMore = true,
        ShowPercentage = true
    },
    ["Bullets"] = {
        Name = "弹药数",
        ProIfMore = true,
        ShowPercentage = false
    },
    ["SprintLength"] = {
        Name = "冲刺到开枪时间",
        ProIfMore = false,
        ShowPercentage = false
    },
}