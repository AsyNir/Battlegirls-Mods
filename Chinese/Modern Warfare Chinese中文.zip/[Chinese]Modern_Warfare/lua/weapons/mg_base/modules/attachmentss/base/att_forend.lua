ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Forend"
ATTACHMENT.Category = "护手"