ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default"
ATTACHMENT.Category = "杂项"
ATTACHMENT.CosmeticChange = true