ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Pump"
ATTACHMENT.Category = "泵"