ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Rail"
ATTACHMENT.Category = "扶手"