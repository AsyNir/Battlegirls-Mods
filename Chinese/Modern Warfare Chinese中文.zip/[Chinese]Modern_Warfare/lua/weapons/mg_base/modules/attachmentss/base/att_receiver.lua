ATTACHMENT.Base = "att_base"
ATTACHMENT.Name = "Default Receiver"
ATTACHMENT.Category = "机匣"